# ADS Project 1: What made you happy today?
### Output folder

The output directory contains analysis output, processed datasets, logs, or other processed things.

