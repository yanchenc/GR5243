# ADS Project 1: What made you happy today?
### Doc folder

The doc directory contains the report or presentation files. It can have subfolders.  